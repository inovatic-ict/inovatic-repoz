EMoRo 2560 Firmwares for the ATmega8U2

This directory contains the firmwares used on the ATmega8U2 on the EMoRo 2560. The arduino-usbdfu directory contains the DFU
bootloader on the 8U2; the arduino-usbserial directory contains the actual
usb to serial firmware.  Both should be compiled against LUFA 100807.  The
two .hex files in this directory combine the dfu and serial firmwares into
a single file to burn onto the 8U2. To burn (EMoRo 2560):
avrdude -p at90usb82 -F -P usb -c avrispmkii -U flash:w:EMoRo-dfu_and_usbserial_combined.hex -U lfuse:w:0xFF:m -U hfuse:w:0xD9:m -U efuse:w:0xF4:m -U lock:w:0x0F:m


Note on USB Vendor IDs (VID) and Product IDs (PID): The arduino-usbdfu
project uses Atmel's VID and MCU-specific PIDs to maintain compatibility
with their FLIP software.  The source code to the arduino-usbserial
project includes Bascom VID and a PID donated by them to Inovatic-ICT.