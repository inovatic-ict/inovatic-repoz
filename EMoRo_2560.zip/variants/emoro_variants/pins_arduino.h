/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA

  $Id: wiring.h 249 2007-02-03 16:52:51Z mellis $
*/

/******************************************************************************* Josip Update Start ******************************************************************/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

#define NUM_DIGITAL_PINS            79
#define NUM_ANALOG_INPUTS           8
#define analogInputToDigitalPin(p)  ((p < 8) ? (p) + 16 : -1)
#define digitalPinHasPWM(p)         (((p) >= 48 && (p) <= 53) || ((p) >= 27 && (p) <= 29) || ((p)==35) || ((p)==37) || ((p)==39) || ((p)==41) || ((p)==62) || ((p)==74))

static const uint8_t BUZ_BUILTIN = 73;
static const uint8_t LED_BUILTIN = 74;

static const uint8_t SS			= 75;
static const uint8_t MOSI		= 76;
static const uint8_t MISO		= 77;
static const uint8_t SCK		= 78;

static const uint8_t SCL		= 55;		/* SCL pin is shared with EX_IO_1 -> EMoRo GLAM board use I2C communication protocol		*/
static const uint8_t SDA		= 56;		/* SDA pin is shared with EX_IO_2 -> EMoRo GLAM board use I2C communication protocol		*/

static const uint8_t IO_0		= 0;
static const uint8_t IO_1		= 1;
static const uint8_t IO_2		= 2;
static const uint8_t IO_3		= 3;
static const uint8_t IO_4		= 4;
static const uint8_t IO_5		= 5;
static const uint8_t IO_6		= 6;
static const uint8_t IO_7		= 7;
static const uint8_t IO_8		= 8;
static const uint8_t IO_9		= 9;
static const uint8_t IO_10		= 10;
static const uint8_t IO_11		= 11;
static const uint8_t IO_12		= 12;
static const uint8_t IO_13		= 13;
static const uint8_t IO_14		= 14;
static const uint8_t IO_15		= 15;

static const uint8_t ADC_0		= 16;
static const uint8_t ADC_1		= 17;
static const uint8_t ADC_2		= 18;
static const uint8_t ADC_3		= 19;
static const uint8_t ADC_4		= 20;
static const uint8_t ADC_5		= 21;
static const uint8_t ADC_6		= 22;
static const uint8_t ADC_7		= 23;

static const uint8_t SERVO_0	= 24;
static const uint8_t SERVO_1	= 25;
static const uint8_t SERVO_2	= 26;
static const uint8_t SERVO_3	= 27;
static const uint8_t SERVO_4    = 28;
static const uint8_t SERVO_5	= 29;
static const uint8_t SERVO_6	= 30;
static const uint8_t SERVO_7	= 31;

static const uint8_t GPP_0_A	= 32;
static const uint8_t GPP_0_B	= 33;
static const uint8_t GPP_1_A	= 34;
static const uint8_t GPP_1_B	= 35;
static const uint8_t GPP_2_A	= 36;
static const uint8_t GPP_2_B	= 37;
static const uint8_t GPP_3_A	= 38;
static const uint8_t GPP_3_B	= 39;
static const uint8_t GPP_4_A	= 40;
static const uint8_t GPP_4_B	= 41;
static const uint8_t GPP_5_A	= 42;
static const uint8_t GPP_5_B	= 43;
static const uint8_t GPP_6_A	= 44;
static const uint8_t GPP_6_B	= 45;
static const uint8_t GPP_7_A	= 46;
static const uint8_t GPP_7_B	= 47;

static const uint8_t PWM_0		= 48;
static const uint8_t PWM_1		= 49;
static const uint8_t PWM_2		= 50;
static const uint8_t PWM_3		= 51;
static const uint8_t PWM_4		= 52;
static const uint8_t PWM_5		= 53;
static const uint8_t IO_16		= 54;

static const uint8_t EX_IO_0	= 55;		/* SCL pin is shared with EX_IO_1 -> EMoRo GLAM board use I2C communication protocol		*/
static const uint8_t EX_IO_1	= 56;		/* SDA pin is shared with EX_IO_2 -> EMoRo GLAM board use I2C communication protocol		*/
static const uint8_t EX_IO_2	= 57;
static const uint8_t EX_IO_3	= 58;
static const uint8_t EX_IO_4	= 59;
static const uint8_t EX_IO_5	= 60;
static const uint8_t EX_IO_6	= 61;
static const uint8_t EX_IO_7	= 62;
static const uint8_t EX_IO_8	= 63;
static const uint8_t EX_IO_9	= 64;
static const uint8_t EX_IO_10	= 65;
static const uint8_t EX_IO_11	= 66;
static const uint8_t EX_IO_12	= 67;
static const uint8_t EX_IO_13	= 68;
static const uint8_t EX_IO_14	= 69;
static const uint8_t EX_IO_15	= 70;
static const uint8_t EX_IO_16	= 71;
static const uint8_t EX_IO_17	= 72;

/******************************************************************************* Josip Update End ******************************************************************/

// A majority of the pins are NOT PCINTs, SO BE WARNED (i.e. you cannot use them as receive pins)
// Only pins available for RECEIVE (TRANSMIT can be on any pin):
// (I've deliberately left out pin mapping to the Hardware USARTs - seems senseless to me)
// Pins: 10, 11, 12, 13,  50, 51, 52, 53,  62, 63, 64, 65, 66, 67, 68, 69

/*#define digitalPinToPCICR(p)    ( (((p) >= 10) && ((p) <= 13)) || \
                                  (((p) >= 50) && ((p) <= 53)) || \
                                  (((p) >= 62) && ((p) <= 69)) ? (&PCICR) : ((uint8_t *)0) )

#define digitalPinToPCICRbit(p) ( (((p) >= 10) && ((p) <= 13)) || (((p) >= 50) && ((p) <= 53)) ? 0 : \
                                ( (((p) >= 62) && ((p) <= 69)) ? 2 : \
                                0 ) )

#define digitalPinToPCMSK(p)    ( (((p) >= 10) && ((p) <= 13)) || (((p) >= 50) && ((p) <= 53)) ? (&PCMSK0) : \
                                ( (((p) >= 62) && ((p) <= 69)) ? (&PCMSK2) : \
                                ((uint8_t *)0) ) )

#define digitalPinToPCMSKbit(p) ( (((p) >= 10) && ((p) <= 13)) ? ((p) - 6) : \
                                ( ((p) == 50) ? 3 : \
                                ( ((p) == 51) ? 2 : \
                                ( ((p) == 52) ? 1 : \
                                ( ((p) == 53) ? 0 : \
                                ( (((p) >= 62) && ((p) <= 69)) ? ((p) - 62) : \
                                0 ) ) ) ) ) )*/

/******************************************************************************* Josip Update Start ******************************************************************/

//available INT0 to INT6
#define digitalPinToInterrupt(p) ((p) == 51 ? 4 : ((p) >= 62 && (p) <= 63 ? (p) - 57 : ((p) >= 55 && (p) <= 58 ? (p) - 55 : NOT_AN_INTERRUPT)))
//available PCINT23 and PCINT9-PCINT15
#define digitalPinToPCInterrupt(p) ((p) == 0 ? 23 : ((p) >= 1 && (p) <= 15 ?  (p) + 8 : NOT_AN_INTERRUPT))

#ifdef ARDUINO_MAIN

const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	(uint16_t) &DDRA,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
	(uint16_t) &DDRE,
	(uint16_t) &DDRF,
	(uint16_t) &DDRG,
	(uint16_t) &DDRH,
	NOT_A_PORT,
	(uint16_t) &DDRJ,
	(uint16_t) &DDRK,
	(uint16_t) &DDRL,
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
	(uint16_t) &PORTA,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
	(uint16_t) &PORTE,
	(uint16_t) &PORTF,
	(uint16_t) &PORTG,
	(uint16_t) &PORTH,
	NOT_A_PORT,
	(uint16_t) &PORTJ,
	(uint16_t) &PORTK,
	(uint16_t) &PORTL,
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PIN,
	(uint16_t) &PINA,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
	(uint16_t) &PINE,
	(uint16_t) &PINF,
	(uint16_t) &PING,
	(uint16_t) &PINH,
	NOT_A_PIN,
	(uint16_t) &PINJ,
	(uint16_t) &PINK,
	(uint16_t) &PINL,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[] = {
	// PORTLIST		
	// -------------------------------------------		
	PA	, // PA 0 ** 0 ** IO_0  	
	PA	, // PA 1 ** 1 ** IO_1 
	PA	, // PA 2 ** 2 ** IO_2 	
	PA	, // PA 3 ** 3 ** IO_3 	
	PA	, // PA 4 ** 4 ** IO_4 	
	PA	, // PA 5 ** 5 ** IO_5 	
	PA	, // PA 6 ** 6 ** IO_6 	
	PA	, // PA 7 ** 7 ** IO_7
	PC	, // PC 0 ** 8 ** IO_8	
	PC	, // PC 1 ** 9 ** IO_9	
	PC	, // PC 2 ** 10 ** IO_10	
	PC	, // PC 3 ** 11 ** IO_11	
	PC	, // PC 4 ** 12 ** IO_12	
	PC	, // PC 5 ** 13 ** IO_13	
	PC	, // PC 6 ** 14 ** IO_14	
	PC	, // PC 7 ** 15 ** IO_15	
	
	PF	, // PF 0 ** 16 ** ADC_0	
	PF	, // PF 1 ** 17 ** ADC_1	
	PF	, // PF 2 ** 18 ** ADC_2	
	PF	, // PF 3 ** 19 ** ADC_3	
	PK	, // PK 0 ** 20 ** ADC_4	
	PK	, // PK 1 ** 21 ** ADC_5	
	PK	, // PK 2 ** 22 ** ADC_6	
	PK	, // PK 3 ** 23 ** ADC_7	

	PL	, // PL 0 ** 24 ** SERVO_0	
	PL	, // PL 1 ** 25 ** SERVO_1	
	PL	, // PL 2 ** 26 ** SERVO_2	
	PL	, // PL 3 ** 27 ** SERVO_3	
	PL	, // PL 4 ** 28 ** SERVO_4	
	PL	, // PL 5 ** 29 ** SERVO_5	
	PL	, // PL 6 ** 30 ** SERVO_6	
	PL	, // PL 7 ** 31 ** SERVO_7

	PK	, // PK 7 ** 32 ** GPP_0A	
	PH	, // PH 7 ** 33 ** GPP_0B	
	PJ	, // PJ 0 ** 34 ** GPP_1A	
	PH	, // PH 6 ** 35 ** GPP_1B	
	PJ	, // PJ 1 ** 36 ** GPP_2A	
	PH	, // PH 5 ** 37 ** GPP_2B	
	PJ	, // PJ 2 ** 38 ** GPP_3A	
	PH	, // PH 4 ** 39 ** GPP_3B	
	PJ	, // PJ 3 ** 40 ** GPP_4A	
	PH	, // PH 3 ** 41 ** GPP_4B	
	PJ	, // PJ 4 ** 42 ** GPP_5A	
	PH	, // PH 2 ** 43 ** GPP_5B	
	PJ	, // PJ 5 ** 44 ** GPP_6A	
	PH	, // PH 1 ** 45 ** GPP_6B	
	PJ	, // PJ 6 ** 46 ** GPP_7A	
	PH	, // PH 0 ** 47 ** GPP_7B	
	
	PG	, // PG 5 ** 48 ** PWM_0	
	PB	, // PB 7 ** 49 ** PWM_1	
	PE	, // PE 3 ** 50 ** PWM_2	
	PE	, // PE 4 ** 51 ** PWM_3	
	PB	, // PB 5 ** 52 ** PWM_4	
	PB	, // PB 6 ** 53 ** PWM_5	
	PD	, // PD 7 ** 54 ** IO_16

	PD	, // PD 0 ** 55 ** EX_IO_0	
	PD	, // PD 1 ** 56 ** EX_IO_1	
	PD	, // PD 2 ** 57 ** EX_IO_2	
	PD	, // PD 3 ** 58 ** EX_IO_3	
	PD	, // PD 4 ** 59 ** EX_IO_4	
	PD	, // PD 5 ** 60 ** EX_IO_5	
	PD	, // PD 6 ** 61 ** EX_IO_6	
	PE	, // PE 5 ** 62 ** EX_IO_7	
	PE	, // PE 6 ** 63 ** EX_IO_8	
	PE	, // PE 7 ** 64 ** EX_IO_9	
	PG	, // PG 0 ** 65 ** EX_IO_10	
	PG	, // PG 1 ** 66 ** EX_IO_11
	PG	, // PG 2 ** 67 ** EX_IO_12	
	PG	, // PG 3 ** 68 ** EX_IO_13	
	PG	, // PG 4 ** 69 ** EX_IO_14	
	PK	, // PK 5 ** 70 ** EX_IO_15	
	PK	, // PK 6 ** 71 ** EX_IO_16	
	PJ	, // PJ 7 ** 72 ** EX_IO_17	

	PE	, // PE 2 ** 73 ** BUZ_BUILTIN
	PB	, // PB 4 ** 74 ** LED_BUILTIN
	PB	, // PB 0 ** 75 ** SS
	PB	, // PB 2 ** 76 ** MOSI
	PB	, // PB 3 ** 77 ** MISO
	PB	, // PB 1 ** 78 ** SCK
};

/******************************************************************************* Josip Update End ******************************************************************/

/******************************************************************************* Josip Update Start ******************************************************************/

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
	// PIN IN PORT		
	// -------------------------------------------		
	_BV( 0 )	, // PA 0 ** 0 ** IO_0	
	_BV( 1 )	, // PA 1 ** 1 ** IO_1	
	_BV( 2 )	, // PA 2 ** 2 ** IO_2	
	_BV( 3 )	, // PA 3 ** 3 ** IO_3	
	_BV( 4 )	, // PA 4 ** 4 ** IO_4	
	_BV( 5 )	, // PA 5 ** 5 ** IO_5	
	_BV( 6 )	, // PA 6 ** 6 ** IO_6	
	_BV( 7 )	, // PA 7 ** 7 ** IO_7	
	_BV( 0 )	, // PC 0 ** 8 ** IO_8	
	_BV( 1 )	, // PC 1 ** 9 ** IO_9	
	_BV( 2 )	, // PC 2 ** 10 ** IO_10	
	_BV( 3 )	, // PC 3 ** 11 ** IO_11	
	_BV( 4 )	, // PC 4 ** 12 ** IO_12	
	_BV( 5 )	, // PC 5 ** 13 ** IO_13	
	_BV( 6 )	, // PC 6 ** 14 ** IO_14	
	_BV( 7 )	, // PC 7 ** 15 ** IO_15	
	
	_BV( 0 )	, // PF 0 ** 16 ** ADC_0	
	_BV( 1 )	, // PF 1 ** 17 ** ADC_1	
	_BV( 2 )	, // PF 2 ** 18 ** ADC_2	
	_BV( 3 )	, // PF 3 ** 19 ** ADC_3	
	_BV( 0 )	, // PK 0 ** 20 ** ADC_4	
	_BV( 1 )	, // PK 1 ** 21 ** ADC_5	
	_BV( 2 )	, // PK 2 ** 22 ** ADC_6	
	_BV( 3 )	, // PK 3 ** 23 ** ADC_7	

	_BV( 0 )	, // PL 0 ** 24 ** SERVO_0	
	_BV( 1 )	, // PL 1 ** 25 ** SERVO_1	
	_BV( 2 )	, // PL 2 ** 26 ** SERVO_2	
	_BV( 3 )	, // PL 3 ** 27 ** SERVO_3	
	_BV( 4 )	, // PL 4 ** 28 ** SERVO_4	
	_BV( 5 )	, // PL 5 ** 29 ** SERVO_5	
	_BV( 6 )	, // PL 6 ** 30 ** SERVO_6	
	_BV( 7 )	, // PL 7 ** 31 ** SERVO_7

	_BV( 7 )	, // PK 7 ** 32 ** GPP_0A	
	_BV( 7 )	, // PH 7 ** 33 ** GPP_0B	
	_BV( 0 )	, // PJ 0 ** 34 ** GPP_1A	
	_BV( 6 )	, // PH 6 ** 35 ** GPP_1B	
	_BV( 1 )	, // PJ 1 ** 36 ** GPP_2A	
	_BV( 5 )	, // PH 5 ** 37 ** GPP_2B	
	_BV( 2 )	, // PJ 2 ** 38 ** GPP_3A	
	_BV( 4 )	, // PH 4 ** 39 ** GPP_3B	
	_BV( 3 )	, // PJ 3 ** 40 ** GPP_4A	
	_BV( 3 )	, // PH 3 ** 41 ** GPP_4B	
	_BV( 4 )	, // PJ 4 ** 42 ** GPP_5A	
	_BV( 2 )	, // PH 2 ** 43 ** GPP_5B	
	_BV( 5 )	, // PJ 5 ** 44 ** GPP_6A	
	_BV( 1 )	, // PH 1 ** 45 ** GPP_6B	
	_BV( 6 )	, // PJ 6 ** 46 ** GPP_7A	
	_BV( 0 )	, // PH 0 ** 47 ** GPP_7B	

	_BV( 5 )	, // PG 5 ** 48 ** PWM_0	
	_BV( 7 )	, // PB 7 ** 49 ** PWM_1	
	_BV( 3 )	, // PE 3 ** 50 ** PWM_2	
	_BV( 4 )	, // PE 4 ** 51 ** PWM_3	
	_BV( 5 )	, // PB 5 ** 52 ** PWM_4	
	_BV( 6 )	, // PB 6 ** 53 ** PWM_5	
	_BV( 7 )	, // PD 7 ** 54 ** IO_16

	_BV( 0 )	, // PD 0 ** 55 ** EX_IO_0	
	_BV( 1 )	, // PD 1 ** 56 ** EX_IO_1	
	_BV( 2 )	, // PD 2 ** 57 ** EX_IO_2	
	_BV( 3 )	, // PD 3 ** 58 ** EX_IO_3	
	_BV( 4 )	, // PD 4 ** 59 ** EX_IO_4	
	_BV( 5 )	, // PD 5 ** 60 ** EX_IO_5	
	_BV( 6 )	, // PD 6 ** 61 ** EX_IO_6	
	_BV( 5 )	, // PE 5 ** 62 ** EX_IO_7	
	_BV( 6 )	, // PE 6 ** 63 ** EX_IO_8	
	_BV( 7 )	, // PE 7 ** 64 ** EX_IO_9		
	_BV( 0 )	, // PG 0 ** 65 ** EX_IO_10	
	_BV( 1 )	, // PG 1 ** 66 ** EX_IO_11	
	_BV( 2 )	, // PG 2 ** 67 ** EX_IO_12	
	_BV( 3 )	, // PG 3 ** 68 ** EX_IO_13	
	_BV( 4 )	, // PG 4 ** 69 ** EX_IO_14	
	_BV( 5 )	, // PK 5 ** 70 ** EX_IO_15
	_BV( 6 )	, // PK 6 ** 71 ** EX_IO_16
	_BV( 7 )	, // PJ 7 ** 72 ** EX_IO_17
	
	_BV( 2 )	, // PE 2 ** 73 ** BUZ_BUILTIN
	_BV( 4 )	, // PB 4 ** 74 ** LED_BUILTIN
	_BV( 0 )	, // PB 0 ** 75 ** SS
	_BV( 2 )	, // PB 2 ** 76 ** MOSI
	_BV( 3 )	, // PB 3 ** 77 ** MISO
	_BV( 1 )	, // PB 1 ** 78 ** SCK
};

/******************************************************************************* Josip Update End ******************************************************************/

/******************************************************************************* Josip Update Start ******************************************************************/

const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
	// TIMERS		
	// -------------------------------------------		
	NOT_ON_TIMER	, // PA 0 ** 0 ** IO_0
	NOT_ON_TIMER	, // PA 1 ** 1 ** IO_1	
	NOT_ON_TIMER	, // PA 2 ** 2 ** IO_2	
	NOT_ON_TIMER	, // PA 3 ** 3 ** IO_3	
	NOT_ON_TIMER	, // PA 4 ** 4 ** IO_4	
	NOT_ON_TIMER	, // PA 5 ** 5 ** IO_5	
	NOT_ON_TIMER	, // PA 6 ** 6 ** IO_6	
	NOT_ON_TIMER	, // PA 7 ** 7 ** IO_7	
	NOT_ON_TIMER	, // PC 0 ** 8 ** IO_8	
	NOT_ON_TIMER	, // PC 1 ** 9 ** IO_9	
	NOT_ON_TIMER	, // PC 2 ** 10 ** IO_10	
	NOT_ON_TIMER	, // PC 3 ** 11 ** IO_11	
	NOT_ON_TIMER	, // PC 4 ** 12 ** IO_12	
	NOT_ON_TIMER	, // PC 5 ** 13 ** IO_13	
	NOT_ON_TIMER	, // PC 6 ** 14 ** IO_14	
	NOT_ON_TIMER	, // PC 7 ** 15 ** IO_15

	NOT_ON_TIMER	, // PF 0 ** 16 ** ADC_0	
	NOT_ON_TIMER	, // PF 1 ** 17 ** ADC_1	
	NOT_ON_TIMER	, // PF 2 ** 18 ** ADC_2	
	NOT_ON_TIMER	, // PF 3 ** 19 ** ADC_3	
	NOT_ON_TIMER	, // PK 0 ** 20 ** ADC_4	
	NOT_ON_TIMER	, // PK 1 ** 21 ** ADC_5	
	NOT_ON_TIMER	, // PK 2 ** 22 ** ADC_6	
	NOT_ON_TIMER	, // PK 3 ** 23 ** ADC_7	

	NOT_ON_TIMER	, // PL 0 ** 24 ** SERVO_0	
	NOT_ON_TIMER	, // PL 1 ** 25 ** SERVO_1
	NOT_ON_TIMER	, // PL 2 ** 26 ** SERVO_2
	TIMER5A	,									// PL 3 ** 27 ** SERVO_3
	TIMER5B	,									// PL 4 ** 28 ** SERVO_4	
	TIMER5C	,									// PL 5 ** 29 ** SERVO_5	
	NOT_ON_TIMER	, // PL 6 ** 30 ** SERVO_6	
	NOT_ON_TIMER	, // PL 7 ** 31 ** SERVO_7
	
	NOT_ON_TIMER	, // PK 7 ** 32 ** GPP_0A	
	NOT_ON_TIMER	, // PH 7 ** 33 ** GPP_0B	
	NOT_ON_TIMER	, // PJ 0 ** 34 ** GPP_1A	
	TIMER2B	,									// PH 6 ** 35 ** GPP_1B	
	NOT_ON_TIMER	, // PJ 1 ** 36 ** GPP_2A	
	TIMER4C	,									// PH 5 ** 37 ** GPP_2B	
	NOT_ON_TIMER	, // PJ 2 ** 38 ** GPP_3A	
	TIMER4B	,									// PH 4 ** 39 ** GPP_3B	
	NOT_ON_TIMER	, // PJ 3 ** 40 ** GPP_4A	
	TIMER4A	,									// PH 3 ** 41 ** GPP_4B	
	NOT_ON_TIMER	, // PJ 4 ** 42 ** GPP_5A	
	NOT_ON_TIMER	, // PH 2 ** 43 ** GPP_5B	
	NOT_ON_TIMER	, // PJ 5 ** 44 ** GPP_6A	
	NOT_ON_TIMER	, // PH 1 ** 45 ** GPP_6B	
	NOT_ON_TIMER	, // PJ 6 ** 46 ** GPP_7A	
	NOT_ON_TIMER	, // PH 0 ** 47 ** GPP_7B

	TIMER0B	,									// PG 5 ** 48 ** PWM_0	
	TIMER0A	,									// PB 7 ** 49 ** PWM_1	
	TIMER3A	,									// PE 3 ** 50 ** PWM_2	
	TIMER3B	,									// PE 4 ** 51 ** PWM_3	
	TIMER1A	,									// PB 5 ** 52 ** PWM_4	
	TIMER1B	,									// PB 6 ** 53 ** PWM_5	
	NOT_ON_TIMER	, // PD 7 ** 54 ** IO_16

	NOT_ON_TIMER	, // PD 0 ** 55 ** EX_IO_0	
	NOT_ON_TIMER	, // PD 1 ** 56 ** EX_IO_1	
	NOT_ON_TIMER	, // PD 2 ** 57 ** EX_IO_2	
	NOT_ON_TIMER	, // PD 3 ** 58 ** EX_IO_3	
	NOT_ON_TIMER	, // PD 4 ** 59 ** EX_IO_4	
	NOT_ON_TIMER	, // PD 5 ** 60 ** EX_IO_5	
	NOT_ON_TIMER	, // PD 6 ** 61 ** EX_IO_6
	TIMER3C	,									// PE 5 ** 62 ** EX_IO_7	
	NOT_ON_TIMER	, // PE 6 ** 63 ** EX_IO_8	
	NOT_ON_TIMER	, // PE 7 ** 64 ** EX_IO_9	
	NOT_ON_TIMER	, // PG 0 ** 65 ** EX_IO_10	
	NOT_ON_TIMER	, // PG 1 ** 66 ** EX_IO_11	
	NOT_ON_TIMER	, // PG 2 ** 67 ** EX_IO_12	
	NOT_ON_TIMER	, // PG 3 ** 68 ** EX_IO_13	
	NOT_ON_TIMER	, // PG 4 ** 69 ** EX_IO_14	
	NOT_ON_TIMER	, // PK 5 ** 70 ** EX_IO_15	
	NOT_ON_TIMER	, // PK 6 ** 71 ** EX_IO_16	
	NOT_ON_TIMER	, // PJ 7 ** 72 ** EX_IO_17
	
	NOT_ON_TIMER	, // PE 2 ** 73 ** BUZ_BUILTIN
	TIMER2A	,									// PB 4 ** 74 ** LED_BUILTIN
	NOT_ON_TIMER	, // PB 0 ** 75 ** SS
	NOT_ON_TIMER	, // PB 2 ** 76 ** MOSI
	NOT_ON_TIMER	, // PB 3 ** 77 ** MISO
	NOT_ON_TIMER	, // PB 1 ** 78 ** SCK
};

/******************************************************************************* Josip Update End ******************************************************************/

#endif

#endif