Hex se prebacuje premo ISP konektora i STK500 na pad konektoru na botom layeru
Device je ATMEGA8U2
Fuses su: Extended 0xF4, High 0xD9 i Low 0xFF
Lock bit je: 0x0F ili naknadno procitano FF

 